var searchData=
[
  ['rawaxis1d',['RawAxis1D',['../class_o_v_r_input.html#a9c9eff2910ca07d1fb0e924273ebefaf',1,'OVRInput']]],
  ['rawaxis2d',['RawAxis2D',['../class_o_v_r_input.html#a973c161bfb3bd6d0cc16c3a0b56c9f4a',1,'OVRInput']]],
  ['rawbutton',['RawButton',['../class_o_v_r_input.html#a9d6423af820e22b93f0b33a4fc4bf77a',1,'OVRInput']]],
  ['rawneartouch',['RawNearTouch',['../class_o_v_r_input.html#ac9c3c10aa9911507c6dc66e2dd6ec60e',1,'OVRInput']]],
  ['rawtouch',['RawTouch',['../class_o_v_r_input.html#a6e130faa2035c5b20853c1177d909cc6',1,'OVRInput']]]
];
