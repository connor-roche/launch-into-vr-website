var searchData=
[
  ['textplaybackspeed',['TextPlayBackSpeed',['../class_dialogue_element.html#a14e05abcef33f93b97d5b3ae2c11dd1d',1,'DialogueElement']]]
];
