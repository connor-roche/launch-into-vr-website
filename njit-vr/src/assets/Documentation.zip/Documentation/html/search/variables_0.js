var searchData=
[
  ['ballsoundbig',['BallSoundBig',['../class_ball_controls.html#a8b478ef0dc12f8683cfdd7e485ee9d20',1,'BallControls']]],
  ['ballsoundsmall',['BallSoundSmall',['../class_ball_controls.html#acd4d5b722bd7ad4fd32d6df3cd9b5191',1,'BallControls']]]
];
