var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuv",
  1: "bdefimrstv",
  2: "v",
  3: "bcdefimrstv",
  4: "abcdefghilmnorstu",
  5: "bcdfimpst",
  6: "acrs",
  7: "dhilnru",
  8: "cdiru",
  9: "eo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

